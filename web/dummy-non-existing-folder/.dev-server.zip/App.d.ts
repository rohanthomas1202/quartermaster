export * from './compiled-types/WeeklyCommitsApp';
export { default } from './compiled-types/WeeklyCommitsApp';