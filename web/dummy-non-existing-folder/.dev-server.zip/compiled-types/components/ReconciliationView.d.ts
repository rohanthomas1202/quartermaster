export declare function ReconciliationView(): import("react/jsx-runtime").JSX.Element;
