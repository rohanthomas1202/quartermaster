export declare function ManagerDashboard(): import("react/jsx-runtime").JSX.Element;
