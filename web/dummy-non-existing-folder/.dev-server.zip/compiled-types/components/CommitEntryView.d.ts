export declare function CommitEntryView(): import("react/jsx-runtime").JSX.Element;
